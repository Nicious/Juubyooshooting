# pragma once
# include "bullet.hpp"


#define JIKIX_INIT			417
#define JIKIY_INIT			350

BulletManager				bullet_manager;
int							jikix, jikiy, jiki_speed, jikilife;
Stopwatch					swatch;

inline double GetJikiDir(double objx, double objy)
{
	if (jikix == objx)return (jikiy > objy) ? HalfPi : -HalfPi;
	return  atan((double)(jikiy - objy) / (double)(jikix - objx)) + ((jikix < objx) ? Pi : 0.0);
}

//1�̒n�_���畡���̒e�𔭎˂���Brad_space���p�x�Ԋu�Btargeting�Ŏ��@�_���B��e�Ƌ����e�ǂ����OK�B
void	addbullet_multi(double x, double y, BulletType type, int attr, int count, double rad_space, bool targeting)
{
	double rad = (targeting) ? GetJikiDir(x, y) : HalfPi;
	if (count & 1) rad -= (rad_space * (count >> 1));
	else rad -= ((rad_space * (count >> 1)) - (rad_space / 2.0));

	for (int i = 0; i < count; i++)
	{
		bullet_manager.add_bullet(x, y, rad, type, attr);
		rad += rad_space;
	}
}
