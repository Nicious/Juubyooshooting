﻿
# include <Siv3D.hpp>
# include "Header.h"
# include "bullet.hpp"
# include "enemy.hpp"

enum class GameState
{
	INIT,
	TITLE,
	GAME,
	TOGAMEOVER,
	GAMEOVER,
	TOWIN,
	WIN
};

GameState		state;
EnemyManager	enemy_manager;
int				score;
int				high_score;

inline double	GetJikiDir(double objx, double objy);



/*---------------------------------------------------------------------------------------
画像読み込み(アセット管理)
---------------------------------------------------------------------------------------*/
void LoadTextures()
{
	Image	img_burst(L"image\\bursts.png");
	TextureAssetData	td;

	TextureAsset::Register(L"Title", L"image\\title.png");
	TextureAsset::Register(L"TitleB", L"image\\titleB.png");
	TextureAsset::Register(L"Gamestart", L"image\\gamestart.png");
	TextureAsset::Register(L"Jiki", L"image\\jiki.png");
	String str_id;
	String str_filename;
	for (int i = 0; i < 8; i++)
	{
		str_id = L"Enemy" + ToString(i);
		str_filename = L"image\\Enemy" + ToString(i) + L"T.png";
		TextureAsset::Register(str_id, str_filename);

		str_id = L"Burst" + ToString(i);
		td.texture = Texture(img_burst.clip(100 * i, 0, 100, 100));
		TextureAsset::Register(str_id, td);	
	}
	
	TextureAsset::Register(L"BulletA", L"image\\b_bullet.png");
	TextureAsset::Register(L"BulletJ1", L"image\\r_bulletT.png");
	TextureAsset::Register(L"Gameover", L"image\\gameover.png");
	TextureAsset::Register(L"Gameclear", L"image\\gameclear.png");
}

/*---------------------------------------------------------------------------------------
サウンド読み込み
---------------------------------------------------------------------------------------*/
void	LoadSounds()
{
	SoundAsset::Register(L"Shot0", L"sound\\shot0.wav");
	SoundAsset::Register(L"Burst", L"sound\\burst.wav");
	SoundAsset::Register(L"Hit", L"sound\\hit0.wav");
	SoundAsset::Register(L"Dead", L"sound\\dead.wav");

	SoundAsset::Register(L"Bgm1", L"sound\\BGM1.ogg");
}


/*---------------------------------------------------------------------------------------
キー入力処理周り
---------------------------------------------------------------------------------------*/
void InputProc()
{
	int		bullet_attr = BULLET_ATTR_HIT_TO_ENEMY;

	if (state == GameState::GAME)
	{
		static int spacekey_wait = 0;

		jiki_speed = 8;
		if (Input::KeySpace.pressed)jiki_speed = 3;
		if (Input::KeyUp.pressed)jikiy -= jiki_speed;
		if (Input::KeyDown.pressed)jikiy += jiki_speed;
		if (Input::KeyLeft.pressed)jikix -= jiki_speed;
		if (Input::KeyRight.pressed)jikix += jiki_speed;
		if (jikix < 0)jikix = 0;
		else if (jikix >= Window::Width())jikix = Window::Width() - 1;
		if (jikiy < 0)jikiy = 0;
		else if (jikiy >= Window::Height())jikiy = Window::Height() - 1;

		spacekey_wait--;
		if (Input::KeySpace.pressed && spacekey_wait <= 0)
		{
			SoundAsset(L"Shot0").playMulti();
			bullet_manager.add_bullet(jikix + 2, jikiy - 10, -HalfPi + 0.05, BulletType::BulletJ1, bullet_attr);
			bullet_manager.add_bullet(jikix - 2, jikiy - 10, -HalfPi - 0.05, BulletType::BulletJ1, bullet_attr);
			spacekey_wait = 3;
		}
		if (Input::Key1.clicked)bullet_manager.clear();
	}
}

/*---------------------------------------------------------------------------------------
画面上部スコア表示
---------------------------------------------------------------------------------------*/
void DrawScoreBoard(const Font font)
{
	wchar_t	wc[256];
	swprintf(wc, 256, L"Score  %06d   Hi-Score  %06d", score, high_score);
	font(wc).draw(0, 0);
	font(L"Copyright(C) 2016 Nicious").drawCenter(445);
}

/*---------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------*/
void AddScore(int value)
{
	score += value;
	if (high_score < score)high_score = score;
}

/*---------------------------------------------------------------------------------------
描画処理(StateがGAMEの時)
---------------------------------------------------------------------------------------*/
void Game_DrawProc(const Font& font)
{
	font(L"Time : ", (10000.0 - swatch.ms())/1000).draw(0, 30);
	TextureAsset(L"TitleB").drawAt(320, 130);
	enemy_manager.draw();
	TextureAsset(L"Gamestart").drawAt(320, 350);
	TextureAsset(L"Jiki").drawAt(jikix, jikiy);
	bullet_manager.draw();
}


/*---------------------------------------------------------------------------------------
メイン関数
---------------------------------------------------------------------------------------*/
void Main()
{
	const Font					font(20);
	const Font					fonts(16);
	EasingController<double>	easing_title(800, 130, Easing::Back, 1500);
	EasingController<double>	easing_gameover(1.0, 0.7, Easing::Cubic, 1000);
	EasingController<double>	easing_gameover_bg(255, 96, Easing::Sine, 1000);

	int				destroy_count = 0;

	easing_title.start();
	jikix = JIKIX_INIT;
	jikiy = JIKIY_INIT;
	state = GameState::INIT;
	Texture		tex;

	LoadTextures();
	LoadSounds();
	

	while (System::Update())
	{
		switch (state)
		{
		case GameState::INIT:
			if (!SoundAsset(L"Bgm1").isPlaying())SoundAsset(L"Bgm1").play();
			score = 0;
			destroy_count = 0;
			if (easing_title.isEnd())
			{
				bullet_manager.clear();
				enemy_manager.clear();
				jikix = JIKIX_INIT;
				jikiy = JIKIY_INIT;
				enemy_manager.add_enemy(new EnemyA(55  + 128, 5  + 82));
				enemy_manager.add_enemy(new EnemyB(139 + 128, 50 + 82));
				enemy_manager.add_enemy(new EnemyC(169 + 128, 35 + 82));
				enemy_manager.add_enemy(new EnemyD(207 + 128, 4  + 82));
				enemy_manager.add_enemy(new EnemyE(251 + 128, 63 + 82));
				enemy_manager.add_enemy(new EnemyF(274 + 128, 13 + 82));
				enemy_manager.add_enemy(new EnemyG(313 + 128, 2  + 82));
				swatch.reset();
				swatch.start();
				state = GameState::GAME;
			}
			DrawScoreBoard(fonts);
			TextureAsset(L"Title").drawAt(320, easing_title.easeOut());
			break;
		case GameState::GAME:
			if (swatch.ms() >= 10000)
			{
				ScreenCapture::Request();
				state = GameState::TOGAMEOVER;
			}

			InputProc();

			enemy_manager.action();

			bullet_manager.manage();

			if (bullet_manager.collision_detect(jikix - 2, jikiy - 2, jikix + 2, jikiy + 2, BULLET_ATTR_HIT_TO_PLAYER))
			{
				jikilife--;
				ScreenCapture::Request();
				SoundAsset(L"Bgm1").stop();
				SoundAsset(L"Dead").play();
				state = GameState::TOGAMEOVER;
			}
			for (auto i : *enemy_manager.get_enemiesdata())
			{
				if (i->is_muteki2())continue;
				int damage = bullet_manager.collision_detect(i->get_collision_rect(), BULLET_ATTR_HIT_TO_ENEMY);
				if (i->get_flags() & ENEMY_FLAG_BOSS)
				{
					if (swatch.ms() > 9750)damage = 1000;	//ボスは残り時間0.25ms以内で弾を当てた場合に破壊可
					else AddScore(50 * damage);
				}
				if (damage == 0)continue;
				if (i->damage(damage) <= 0)
				{
					//爆発
					destroy_count++;
					AddScore(10000 - swatch.ms());
					bullet_manager.add_bullet(new Burst(i->get_centerpos().x, i->get_centerpos().y));
					SoundAsset(L"Burst").playMulti();
					if (destroy_count == 7)
					{
						enemy_manager.add_enemy(new EnemyH(128, 82));
					}
					if (destroy_count == 8)
					{
						AddScore(20000);
						ScreenCapture::Request();
						state = GameState::TOWIN;
					}
				}
				else
				{
					SoundAsset(L"Hit").playMulti();
				}
			}

			DrawScoreBoard(fonts);
			Game_DrawProc(font);


			break;
		case GameState::TOWIN:
			tex = Texture(ScreenCapture::GetFrame());
			easing_gameover.reset();
			easing_gameover.start();
			state = GameState::WIN;
			//break;
		case GameState::WIN:
			tex.draw();
			Line(-300, 260, 800, 140).draw(360, Color(0, 0, 0, 196));
			TextureAsset(L"Gameclear").scale(easing_gameover.easeOut()).drawAt(Window::Center().x, Window::Center().y - 80);
			if (Input::MouseL.clicked || Input::KeyEnter.clicked)
			{
				state = GameState::INIT;
				easing_title.reset();
				easing_title.start();
			}
			font(L"Score : ", score).drawCenter(280);
			//Game_DrawProc(font);
			break;
		case GameState::TOGAMEOVER:
			tex = Texture(ScreenCapture::GetFrame());
			state = GameState::GAMEOVER;
			easing_gameover.reset();
			easing_gameover.start();
			easing_gameover_bg.reset();
			easing_gameover_bg.start();
		case GameState::GAMEOVER:
			if (Input::MouseL.clicked || Input::KeyEnter.clicked)
			{
				state = GameState::INIT;
				easing_title.reset();
				easing_title.start();
			}
			tex.draw(Alpha((int)easing_gameover_bg.easeOut()));
			TextureAsset(L"Gameover").scale(easing_gameover.easeOut()).drawAt(Window::Center());
			if (easing_gameover.isEnd())font(L"Press Enter key to restart, Esc key to exit").drawCenter(420);
			break;
		}
		
	}
}





