# pragma once

# include <Siv3D.hpp>
# include <math.h>
# include <vector>	



# define	 	BULLET_ATTR_HIT_TO_PLAYER		0x02
# define		BULLET_ATTR_HIT_TO_ENEMY		0x04
# define		BULLET_ATTR_DAMAGE_TO_BOSS		0x100


enum class BulletType
{
	BulletA,
	BulletJ1
};

class BasicBullet
{
public:
	BasicBullet();
	~BasicBullet();
	double			x;
	double			y;

	virtual void	move();
	virtual void	draw();
	bool			isactive();
	virtual bool	collision_detect(double obj_left, double obj_top, double obj_right, double obj_bottom);
	unsigned int	get_attribute();
private:


protected:
	double			speed;
	double			radius;
	bool			active;
	int				time;
	unsigned int	attribute;


};

BasicBullet::BasicBullet()
{
	time = 0;
	attribute = NULL;
	active = true;
}

BasicBullet::~BasicBullet()
{
}

inline void BasicBullet::move()
{
	time++;
	x += cos(radius) * speed;
	y += sin(radius) * speed;
	if (x < -20 || x > Window::Width() + 20 || y < -20 || y > Window::Height() + 20)active = false;
}

inline void BasicBullet::draw()
{
	return;
}


inline bool BasicBullet::isactive()
{
	return active;
}

inline bool BasicBullet::collision_detect(double obj_left, double obj_top, double obj_right, double obj_bottom)
{
	bool	ret;
	ret = (x - 2 <= obj_right && x + 2 >= obj_left && y - 2 <= obj_bottom && y + 2 >= obj_top);
	if (ret) active = false;
	return ret;
}

inline unsigned int BasicBullet::get_attribute()
{
	return attribute;
}



//--------------------------------------------------------------------------------------------------------------------

class BulletJ1 : public BasicBullet
{
public:
	BulletJ1(double init_x = 0.0, double init_y = 0.0, double init_radius = 0.0, int attr = 0);
	void	draw();
private:
};


inline BulletJ1::BulletJ1(double init_x, double init_y, double init_radius, int attr)
{
	speed = 20.5;
	x = init_x;
	y = init_y;
	radius = init_radius;
	attribute = attr;
}

inline void BulletJ1::draw()
{
	//t_bulletJ1.rotate(radius).drawAt(x, y);
	TextureAsset(L"BulletJ1").rotate(radius).drawAt(x, y);
}


//-----------------------------------------------------------------------------------------------------------------


class BulletA : public BasicBullet
{
public:
	BulletA(double init_x = 0.0, double init_y = 0.0, double init_radius = 0.0, int attr = 0);
	void	draw();
private:
};


inline BulletA::BulletA(double init_x, double init_y, double init_radius, int attr)
{
	speed = 9;
	x = init_x;
	y = init_y;
	radius = init_radius;
	attribute = attr;
}

inline void BulletA::draw()
{
	//t_bulletA.rotate(radius).drawAt(x, y);
	TextureAsset(L"BulletA").rotate(radius).drawAt(x, y);
}


//-----------------------------------------------------------------------------------------------------------
class Burst : public BasicBullet
{
public:
	Burst(double init_x = 0.0, double init_y = 0.0, int attr = 0, double scale = 1.0, int additional_burst_count = 8);
	void draw();
	void move();
private:
	int			additional_burst_count;
	double		scale;
};

inline Burst::Burst(double init_x, double init_y, int attr, double scale,  int additional_burst_count)
{
	x = init_x;
	y = init_y;
	attribute = attr;
	speed = 5+Random() * 1.5;
	this->scale = scale;
	this->additional_burst_count = additional_burst_count;
	radius = Random(0.0, Pi * 2);

}

inline void Burst::draw()
{
	TextureAsset(L"Burst" + ToString(time>>2)).scale(scale).drawAt(x, y);
}

inline void Burst::move()
{
	time++;
	/*
	x += cos(radius) * speed;
	y += sin(radius) * speed;
	*/
	if (x < -20 || x > Window::Width() + 20 || y < -20 || y > Window::Height() + 20 || time >= 32)active = false;
	/*
	double	dir;
	time++;
	if (Random() < 0.4 && additional_burst_count > 0)
	{
		additional_burst_count--;
		dir = Random(0.0, 2 * Pi);

	}
	*/


}



//-----------------------------------------------------------------------------------------------------------



class BulletManager
{
public:
	void	clear();
	void	manage();
	void	draw();
	int		getbulletcount();

	void	add_bullet(double x, double y, double radius, BulletType type, int attr);
	void	add_bullet(BasicBullet *bullet);
	int		collision_detect(double obj_left, double obj_top, double obj_right, double obj_bottom, unsigned int attribute_filter);
	int		collision_detect(Rect	rc, unsigned int attribute_filter);

private:
	std::list<BasicBullet*>	bullets;	

};





//�e�𔭐��Btype��Enum�Battr��BULLET_ATTR_�Ȃ񂿂��B
inline void BulletManager::add_bullet(double x, double y, double radius, BulletType type, int attr)
{
	if (type == BulletType::BulletA)
	{
		bullets.push_back(new BulletA(x, y, radius, attr));
	}
	if (type == BulletType::BulletJ1)
	{
		bullets.push_back(new BulletJ1(x, y, radius, attr));
	}
}

inline void BulletManager::add_bullet(BasicBullet * bullet)
{
	bullets.push_back(bullet);
}

inline void BulletManager::clear()
{
	for (auto it = std::begin(bullets); it != std::end(bullets);)
	{
		delete *it;
		it = bullets.erase(it);
		if (bullets.size() == 0)break;
	}
}

//�ړ��Ɨv��Ȃ��Ȃ����̂��������鏈��
inline void BulletManager::manage()
{
	for (auto it = std::begin(bullets); it != std::end(bullets); )
	{
		(*it)->move();
		if ((*it)->isactive() == false)
		{
			delete *it;
			it = bullets.erase(it);	//erase�ɂ������̃C�e���[�^�̒l�͎g�p�s�\�ɂȂ�B�߂�l�����������̂ł�����L������B
		}
		else it++;
	}
}

inline void BulletManager::draw()
{
	for (auto it = std::begin(bullets); it != std::end(bullets); it++)
	{
		(*it)->draw();
	}
}

//�w�肵���t���O�����̒e���w��̋�`�ɐڐG���Ă���ꍇ�Ƀq�b�g����Ԃ��B
inline int BulletManager::collision_detect(double obj_left, double obj_top, double obj_right, double obj_bottom, unsigned int attribute_filter)
{
	bool	ret = 0;
	for (auto it = std::begin(bullets); it != end(bullets); it++)
	{
		if((*it)->get_attribute() & attribute_filter)
		{
			if ((*it)->collision_detect(obj_left, obj_top, obj_right, obj_bottom))ret++;
		}
	}
	return ret;
}

inline int BulletManager::collision_detect(Rect rc, unsigned int attribute_filter)
{
	return collision_detect(rc.x, rc.y, rc.x + rc.w, rc.y + rc.h, attribute_filter);
}

inline int BulletManager::getbulletcount()
{
	return bullets.size();
}

//----------------------------------------------------------------------------------------------------------------------

