# pragma once

# include <Siv3D.hpp>
# include "Header.h"

#define		ENEMY_FLAG_NO_FLAG		0
#define		ENEMY_FLAG_MUTEKI2		0x2			//�e�����蔲����
#define		ENEMY_FLAG_NO_DRAW		0x4			//�`�悵�Ȃ� 
#define		ENEMY_FLAG_BOSS			0x10000		//�{�X�t���O


class BasicEnemy
{
public:
	BasicEnemy();

	virtual void	action() = 0;
	virtual void	draw();
	virtual int		damage(int damage_value); 
	Rect			get_collision_rect();
	unsigned int	get_flags();
	Point			get_pos();
	Point			get_centerpos();
	bool			is_muteki2();
protected:
	int 	life;
	int		width;
	int		height;
	int		texturenum;

	int				x;
	int				y;
	int				time;
	unsigned int	flags;
};

BasicEnemy::BasicEnemy()
{
	life = 10;
	width = 16;
	height = 16;
	flags = ENEMY_FLAG_NO_FLAG;
}

inline void BasicEnemy::draw()
{
	if (flags & ENEMY_FLAG_NO_DRAW)return;
	String	str = L"Enemy" + ToString(texturenum);
	TextureAsset(str).draw(x, y);
}

inline Rect BasicEnemy::get_collision_rect()
{
	return Rect(x, y, width, height);
}

inline unsigned int BasicEnemy::get_flags()
{
	return flags;
}

inline Point BasicEnemy::get_pos()
{
	return Point(x,y);
}

inline Point BasicEnemy::get_centerpos()
{
	return Point(x + (width>>1), y + (width>>1));
}

inline bool BasicEnemy::is_muteki2()
{
	return (flags & ENEMY_FLAG_MUTEKI2) != 0;
}

//damage_value �͐��̐��A�c��Life���Ԃ�
inline int BasicEnemy::damage(int damage_value)
{
	life -= damage_value;
	if (life <= 0)flags |= (ENEMY_FLAG_MUTEKI2 | ENEMY_FLAG_NO_DRAW);
	return life;
}


//----------------------------------------------------------------------------------


class EnemyA : public BasicEnemy
{
public:
	EnemyA(int x, int y);
	void	action();
};

inline EnemyA::EnemyA(int x, int y)
{
	this->x = x;
	this->y = y;
	life = 9;
	width = 72;
	height = 67;
	texturenum = 0;
}

void EnemyA::action()
{
	time++;
	if (life <= 0)return;
	if (!(time & 0x5F))
	{
		addbullet_multi(x + width / 2, y + height / 2, BulletType::BulletA, BULLET_ATTR_HIT_TO_PLAYER, 5, 0.2, true);
	}
}



//--------------------------------------------------------------------------------------
class EnemyB : public BasicEnemy
{
public:
	EnemyB(int x, int y);
	void	action();
};

inline EnemyB::EnemyB(int x, int y)
{
	this->x = x;
	this->y = y;
	time = 0;
	life = 11;
	width = 49;
	height = 34;
	texturenum = 1;
}

void EnemyB::action()
{
	time++;
	if (life <= 0)return;
	if (!(time & 0x1FF))
	{
		addbullet_multi(x + width / 2, y + height / 2, BulletType::BulletA, BULLET_ATTR_HIT_TO_PLAYER, 31, 0.1, false);
	}
}



//--------------------------------------------------------------------------------------
class EnemyC : public BasicEnemy
{
public:
	EnemyC(int x, int y);
	void	action();
};

inline EnemyC::EnemyC(int x, int y)
{
	this->x = x;
	this->y = y;
	life = 10;
	width = 39;
	height = 17;
	texturenum = 2;
}

void EnemyC::action()
{
	time++;
	if (life <= 0)return;
	if (!(time & 0x1F))
	{
		addbullet_multi(x + width / 2, y + height / 2, BulletType::BulletA, BULLET_ATTR_HIT_TO_PLAYER, 2, 0.35, true);
	}
}



//--------------------------------------------------------------------------------------
class EnemyD : public BasicEnemy
{
public:
	EnemyD(int x, int y);
	void	action();
};

inline EnemyD::EnemyD(int x, int y)
{
	this->x = x;
	this->y = y;
	time = 14;
	life = 10;
	width = 60;
	height = 51;
	texturenum = 3;
}

void EnemyD::action()
{
	time++;
	if (life <= 0)return;
	if (!(time & 0xF))
	{
		bullet_manager.add_bullet(x + width / 2, y + height, HalfPi, BulletType::BulletA, BULLET_ATTR_HIT_TO_PLAYER);
	}
}



//--------------------------------------------------------------------------------------
class EnemyE : public BasicEnemy
{
public:
	EnemyE(int x, int y);
	void	action();
};

inline EnemyE::EnemyE(int x, int y)
{
	time = 25;
	this->x = x;
	this->y = y;
	life = 10;
	width = 26;
	height = 21;
	texturenum = 4;
}

void EnemyE::action()
{
	time++;
	if (life <= 0)return;
	if (!(time & 0x1F))
	{
		bullet_manager.add_bullet(x+width/2, y+height/2, HalfPi, BulletType::BulletA, BULLET_ATTR_HIT_TO_PLAYER);
	}

	//�������
	if (time == 26 || time == 27)
	{
		bullet_manager.add_bullet(x + width / 2, y + height, HalfPi+0.2, BulletType::BulletA, BULLET_ATTR_HIT_TO_PLAYER);
	}
}



//--------------------------------------------------------------------------------------
class EnemyF : public BasicEnemy
{
public:
	EnemyF(int x, int y);
	void	action();
};

inline EnemyF::EnemyF(int x, int y)
{
	time = 0;
	this->x = x;
	this->y = y;
	life = 13;
	width = 42;
	height = 56;
	texturenum = 5;
}

void EnemyF::action()
{
	time++;
	if (life <= 0)return;
	if (!(time & 0xF))
	{
		bullet_manager.add_bullet(x + width / 2, y + height / 2, HalfPi, BulletType::BulletA, BULLET_ATTR_HIT_TO_PLAYER);
	}
}



//--------------------------------------------------------------------------------------
class EnemyG : public BasicEnemy
{
public:
	EnemyG(int x, int y);
	void	action();
};

inline EnemyG::EnemyG(int x, int y)
{
	this->x = x;
	this->y = y;
	time = 31;
	life = 10;
	width = 46;
	height = 71;
	texturenum = 6;
}

void EnemyG::action()
{
	time++;
	if (life <= 0)return;
	if (!(time & 0x1F))
	{
		bullet_manager.add_bullet(x + width / 2, y + height / 2, GetJikiDir(x + width / 2,y + height / 2), BulletType::BulletA, BULLET_ATTR_HIT_TO_PLAYER);
	}
}



//--------------------------------------------------------------------------------------
class EnemyH : public BasicEnemy
{
public:
	EnemyH(int x, int y);
	void	action();
};

inline EnemyH::EnemyH(int x, int y)
{
	this->x = x;
	this->y = y;
	time = 0;
	life = 999;
	width = 384;
	height = 96;
	texturenum = 7;
	flags = ENEMY_FLAG_BOSS;
}

void EnemyH::action()
{
	time++;
	if (life <= 0)return;
	life = 999;

	if (time%100>=0 && time%100 < 7)
	{
		if (time % 100 < 2)addbullet_multi(x + width / 2, y + height / 2, BulletType::BulletA, BULLET_ATTR_HIT_TO_PLAYER, 2, 0.08, true);
		bullet_manager.add_bullet(x+(width>>1), y+(height>>1), GetJikiDir(x + (width >> 1), y + (height>>1)), BulletType::BulletA, BULLET_ATTR_HIT_TO_PLAYER);
	}
	if (!(time & 0xF))
	{
		addbullet_multi(x + width / 2, y + height / 2, BulletType::BulletA, BULLET_ATTR_HIT_TO_PLAYER, 4, 0.6, true);
	}
	if (!(time & 0x1))
	{
		bullet_manager.add_bullet(x + (width >> 1), y + (height >> 1), 0.1*(time>>1) , BulletType::BulletA, BULLET_ATTR_HIT_TO_PLAYER);
	}
	if ((time & 0x3F) < 30)
	{
		bullet_manager.add_bullet(x, y + (height >> 1), GetJikiDir(x, y + (height >> 1)), BulletType::BulletA, BULLET_ATTR_HIT_TO_PLAYER);
		bullet_manager.add_bullet(x+width, y + (height >> 1), GetJikiDir(x+width, y + (height >> 1)), BulletType::BulletA, BULLET_ATTR_HIT_TO_PLAYER);
	}
}



//--------------------------------------------------------------------------------------
class EnemyManager
{
public:
	void add_enemy(BasicEnemy *enemy);
	void clear();
	void action();
	void draw();
	~EnemyManager();
	std::list<BasicEnemy*>	*get_enemiesdata();
private:
	std::list<BasicEnemy*>	Enemies;
};

inline void EnemyManager::action()
{
	for (auto i : Enemies)i->action();
}

void EnemyManager::draw()
{
	for (auto i : Enemies)i->draw();
}

inline EnemyManager::~EnemyManager()
{
	for (auto it : Enemies)
	{
		delete it;
	}
}

inline std::list<BasicEnemy*>* EnemyManager::get_enemiesdata()
{
	return &Enemies;
}

inline void EnemyManager::add_enemy(BasicEnemy *enemy)
{
	Enemies.push_back(enemy);
}

void EnemyManager::clear()
{
	for (auto it : Enemies)
	{
		delete it;
	}
	Enemies.clear();
}


//--------------------------------------------------------------------------------------


